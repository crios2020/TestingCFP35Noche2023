package ar.org.centro8.curso.java.proyectofinal.utils.sumar;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import ar.org.centro8.curso.java.proyectofinal.utils.Calculadora;

public class SumarTest {
    Calculadora calc=new Calculadora();

    @Test
    void testSumar1() {
        assertEquals(calc.sumar(2, 2), 4);
    }
    
    @Test
    void testSumar2() {
        assertEquals(calc.sumar(2, 0), 2);
    }

}
