package ar.org.centro8.curso.java.proyectofinal.test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.time.Duration;
import java.time.LocalTime;

import ar.org.centro8.curso.java.proyectofinal.connector.Connector;

public class TestConnection {
    //sh mvnw spring-boot:run
    public static void main(String[] args) {
        //Test de Objetos MOCKS (Objetos simulados)
        //Test de Objetos Stubs
        
        LocalTime ldt1=LocalTime.now();
        try (Connection conn=Connector.getConnection()){
            ResultSet rs=conn
                .createStatement()
                .executeQuery("select version()");
            if(rs.next()){
                System.out.println(rs.getString(1));
                System.out.println("Se conecto a la BD!");
            } else {
                System.out.println("No Se conecto a la BD!");
            }
            rs.close();
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("No Se conecto a la BD!");
        }
        LocalTime ldt2=LocalTime.now();
        Duration duration = Duration.between(ldt1, ldt2);
        System.out.println(duration.toSeconds());
        if(duration.toSeconds()<=2){
            System.out.println("verde");
        }else{
            System.out.println("rojo");
        }
    }
}
