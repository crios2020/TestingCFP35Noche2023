public class Sumar{
    public static void main(String[] args) {
		double nro1=Double.parseDouble(args[0]);
		double nro2=Double.parseDouble(args[1]);
		System.out.println(nro1+nro2);
    }
}
