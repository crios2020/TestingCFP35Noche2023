package com.example.calculadora;

public class Calculadora {

    /**
     * Método para sumar los parámetros de entrada
     * @param nro1 número 1
     * @param nro2 número 2
     * @return resultado de la operación
     */
    public int sumar(int nro1, int nro2){
        //Realizar la suma de los dos parámetros de entrada
        return nro1+nro2;
    }

    /**
     * Método para restar los parámetros de entrada
     * @param nro1 número 1
     * @param nro2 número 2
     * @return resultado de la operación
     */
    public int restar(int nro1, int nro2){
        //TODO Realizar la resta de los dos parámetros de entrada
        return 0;
    }

    /**
     * Método para dividir los parámetros de entrada
     * @param nro1 número 1
     * @param nro2 número 2
     * @return resultado de la operación
     */
    public int dividir(int nro1, int nro2){
        //TODO Realizar la división de los dos parámetros de entrada
        return 0;
    }

    /**
     * Método para multiplicar los parámetros de entrada
     * @param nro1 número 1
     * @param nro2 número 2
     * @return resultado de la operación
     */
    public int multiplicar(int nro1, int nro2){
        //TODO Realizar la multiplicación de los dos parámetros de entrada
        return 0;
    }

}
