package com.example.calculadora;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculadoraApplicationTests {

	@Test
	void sumarEnteros1(){
		assertEquals(new Calculadora().sumar(2,2),4);
	}

	@Test
	void sumarEnteros2(){
		assertEquals(new Calculadora().sumar(3,4),7);
	}

	@Test
	void sumarElementoNeutro1(){
		assertEquals(new Calculadora().sumar(2,0),2);
	}

	@Test
	void sumarElementoNeutro2(){
		assertEquals(new Calculadora().sumar(2,-0),2);
	}

	@Test
	void sumarElementoNeutro3(){
		assertEquals(new Calculadora().sumar(0,0),0);
	}

	@Test
	void sumarElementoNeutro4(){
		assertEquals(new Calculadora().sumar(0,4),4);
	}

	@Test
	void sumarEnterosNegativos1(){
		assertEquals(new Calculadora().sumar(2,-4),-2);
	}

	@Test
	void sumarEnterosNegativos2(){
		assertEquals(new Calculadora().sumar(-2,-4),-6);
	}
}
