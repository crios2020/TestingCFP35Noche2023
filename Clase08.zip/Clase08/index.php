<?php 
	if(			isset($_REQUEST['nro1']) && 
				isset($_REQUEST['nro2']) && 
				$_REQUEST['nro1']!=null && 
				$_REQUEST['nro2'] !=null
	){
		$nro1=$_REQUEST['nro1'];
		$nro2=$_REQUEST['nro2'];
		$resultado=$nro1+$nro2;
		echo $resultado;
	} else {
		echo 'Servicio de suma de números.<br>';
		echo 'Ingrese la url con los parámetros nro1 y nro2<br>';
		echo 'Ejemplo: http://localhost/sumarService/?nro1=4&nro2=5<br>';
	}
?>

