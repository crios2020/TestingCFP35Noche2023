package com.example.calculadora;

public class Calculadora {

    /**
     * Método para sumar los parámetros de entrada
     * @param nro1 número 1
     * @param nro2 número 2
     * @return resultado de la operación
     */
    public int sumar(int nro1, int nro2){
        //TODO Realizar la suma de los dos parámetros de entrada
        return 0;
        //return nro1+nro2;
    }

    /**
     * Método para restar los parámetros de entrada
     * @param nro1 número 1
     * @param nro2 número 2
     * @return resultado de la operación
     */
    public int restar(int nro1, int nro2){
        //TODO Realizar la resta de los dos parámetros de entrada
        return 0;
        //return nro1-nro2;
    }

    /**
     * Método para dividir los parámetros de entrada
     * @param nro1 número 1
     * @param nro2 número 2
     * @return resultado de la operación
     */
    public double dividir(int nro1, int nro2){
        //TODO Realizar la división de los dos parámetros de entrada
        return 0;
        // double resul = 0;
        // if(nro2 == 0){
        //     System.out.println("Error / 0 ");
        // }else{
        //     resul = (double)nro1/nro2;
        // }
        // return resul;
    }

    /**
     * Método para multiplicar los parámetros de entrada
     * @param nro1 número 1
     * @param nro2 número 2
     * @return resultado de la operación
     */
    public int multiplicar(int nro1, int nro2){
        //TODO Realizar la multiplicación de los dos parámetros de entrada
        return 0;
        //return nro1*nro2;
    }

}
