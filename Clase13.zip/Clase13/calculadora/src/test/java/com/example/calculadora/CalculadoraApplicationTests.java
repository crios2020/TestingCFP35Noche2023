package com.example.calculadora;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculadoraApplicationTests {

	@Test
	void sumarEnteros1(){
		assertEquals(new Calculadora().sumar(2,2),4);
	}

	@Test
	void sumarEnteros2(){
		assertEquals(new Calculadora().sumar(3,4),7);
	}

	@Test
	void sumarElementoNeutro1(){
		assertEquals(new Calculadora().sumar(2,0),2);
	}

	@Test
	void sumarElementoNeutro2(){
		assertEquals(new Calculadora().sumar(2,-0),2);
	}

	@Test
	void sumarElementoNeutro3(){
		assertEquals(new Calculadora().sumar(0,0),0);
	}

	@Test
	void sumarElementoNeutro4(){
		assertEquals(new Calculadora().sumar(0,4),4);
	}

	@Test
	void sumarEnterosNegativos1(){
		assertEquals(new Calculadora().sumar(2,-4),-2);
	}

	@Test
	void sumarEnterosNegativos2(){
		assertEquals(new Calculadora().sumar(-2,-4),-6);
	}

	@Test
	void restarEnteros1(){
		assertEquals(new Calculadora().restar(2,2),0);
	}

	@Test
	void restarEnteros2(){
		assertEquals(new Calculadora().restar(3,4),-1);
	}

	@Test
	void restarElementoNeutro1(){
		assertEquals(new Calculadora().restar(2,0),2);
	}

	@Test
	void restarElementoNeutro2(){
		assertEquals(new Calculadora().restar(2,-0),2);
	}

	@Test
	void restarElementoNeutro3(){
		assertEquals(new Calculadora().restar(0,0),0);
	}

	@Test
	void restarElementoNeutro4(){
		assertEquals(new Calculadora().restar(0,4),-4);
	}

	@Test
	void restarEnterosNegativos1(){
		assertEquals(new Calculadora().restar(2,-4),6);
	}

	@Test
	void restarEnterosNegativos2(){
		assertEquals(new Calculadora().restar(-2,-4),2);
	}

	@Test
	void multiplicarEnteros1(){
		assertEquals(new Calculadora().multiplicar(2,2),4);
	}

	@Test
	void multiplicarEnteros2(){
		assertEquals(new Calculadora().multiplicar(3,4),12);
	}

	@Test
	void multiplicarElementoNeutro1(){
		assertEquals(new Calculadora().multiplicar(2,0),0);
	}

	@Test
	void multiplicarElementoNeutro2(){
		assertEquals(new Calculadora().multiplicar(2,-0),0);
	}

	@Test
	void multiplicarElementoNeutro3(){
		assertEquals(new Calculadora().multiplicar(0,0),0);
	}

	@Test
	void multiplicarElementoNeutro4(){
		assertEquals(new Calculadora().multiplicar(0,4),0);
	}

	@Test
	void multiplicarEnterosNegativos1(){
		assertEquals(new Calculadora().multiplicar(2,-4),-8);
	}

	@Test
	void multiplicarEnterosNegativos2(){
		assertEquals(new Calculadora().multiplicar(-2,-4),8);
	}

	@Test
	void dividirEnteros1(){
		assertEquals(new Calculadora().dividir(2,2),1);
	}

	@Test
	void dividirEnteros2(){
		assertEquals(new Calculadora().dividir(3,4),0.75);
	}

	@Test
	void dividirElementoNeutro1(){
		assertEquals(new Calculadora().dividir(2,0),0);
	}

	@Test
	void dividirElementoNeutro2(){
		assertEquals(new Calculadora().dividir(2,-0),0);
	}

	@Test
	void dividirElementoNeutro3(){
		assertEquals(new Calculadora().dividir(0,0),0);
	}

	@Test
	void dividirElementoNeutro4(){
		assertEquals(new Calculadora().dividir(0,4),0);
	}

	@Test
	void dividirEnterosNegativos1(){
		assertEquals(new Calculadora().dividir(2,-4),-0.5);
	}

	@Test
	void dividirEnterosNegativos2(){
		assertEquals(new Calculadora().dividir(-2,-4),0.5);
	}


}
