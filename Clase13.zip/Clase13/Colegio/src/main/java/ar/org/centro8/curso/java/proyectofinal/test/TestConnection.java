package ar.org.centro8.curso.java.proyectofinal.test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.time.LocalTime;

import ar.org.centro8.curso.java.proyectofinal.connector.Connector;

public class TestConnection {
    //sh mvnw spring-boot:run
    public static void main(String[] args) {
        System.out.println(LocalTime.now());
        try (Connection conn=Connector.getConnection()){
            System.out.println(LocalTime.now());
            ResultSet rs=conn
                .createStatement()
                .executeQuery("select version()");
            if(rs.next()) System.out.println(rs.getString(1));
            System.out.println(LocalTime.now());
            rs.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        System.out.println(LocalTime.now());
    }
}
