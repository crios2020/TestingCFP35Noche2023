package com.example.clase16;

import java.time.LocalDate;
import java.util.Calendar;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class WebController {
    
    @GetMapping("/")
    public String getIndex(Model model){
        model.addAttribute("fecha", LocalDate.now());
        model.addAttribute(("ubicacion"), Calendar
                                                .getInstance()
                                                .getTimeZone()
                                                .getID()
                                                .replace("/", " ")
                                                .replace("_", " "));
        model.addAttribute("so",    System.getProperty("os.name")+" "+
                                    System.getProperty("os.version")+" "+
                                    System.getProperty("os.arch"));
        model.addAttribute("java",  System.getProperty("java.vm.name")+" "+
                                    System.getProperty("java.version"));
        model.addAttribute("user",  System.getProperty("user.name"));
        return "index";
    }

    @GetMapping("/sumar")
    public String getSumar( @RequestParam(name="nro1", required=false, defaultValue="0") double nro1, 
                            @RequestParam(name="nro2", required=false, defaultValue="0") double nro2, 
                            Model model){
            double resultado=nro1+nro2;
            model.addAttribute("resultado", resultado);
        return "sumar";
    }

}
