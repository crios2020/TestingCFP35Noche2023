package ar.org.centro8.curso.java.proyectofinal.utils;

public class Calculadora {
    public long sumar(int nro1, int nro2){
        return (long)nro1+(long)nro2;
    }
}
