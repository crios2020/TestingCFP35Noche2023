package ar.org.centro8.curso.java.proyectofinal.test;

import ar.org.centro8.curso.java.proyectofinal.utils.Calculadora;

public class TestCalculadora {
    public static void main(String[] args) {
        // Test de objetos Mocks (Objetos Simulados)
        // Test stubs

        Calculadora calc =new Calculadora();
        System.out.println(calc.sumar(2,2));            //4
        System.out.println(calc.sumar(2,0));            //2
        

    }    
}
