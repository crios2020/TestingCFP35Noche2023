use colegio;

-- https://www.tutorialesprogramacionya.com/mysqlya/

-- -------------------------------------------------
-- Prueba de tabla cursos
-- -------------------------------------------------

-- registro valido
insert into cursos (titulo,profesor,dia,turno) values 
	('Python','Mendez','LUNES','TARDE');								-- OK

-- Titulo longitud mínima
insert into cursos (titulo,profesor,dia,turno) values 
	('Py','Mendez','LUNES','TARDE');									-- ERROR

-- Titulo longitud máxima
insert into cursos (titulo,profesor,dia,turno) values 
	('El mejor curso de python y del mundo','Mendez','LUNES','TARDE');	-- OK
    
-- Profesor longitud mínima
insert into cursos (titulo,profesor,dia,turno) values 
	('Python','Me','LUNES','TARDE');									-- ERROR
    
-- Profesor longitud máxima
insert into cursos (titulo,profesor,dia,turno) values 
	('Python','El mejor profesor de python y del mundo','LUNES','TARDE');-- OK
    
-- Día Valor Incorrecto
insert into cursos (titulo,profesor,dia,turno) values 
	('Python','Mendez','Osvaldo','TARDE');								-- OK
	
-- Tuno Valor Incorrecto
insert into cursos (titulo,profesor,dia,turno) values 
	('Python','Mendez','LUNES','MEDIANOCHE');							-- OK	
    
-- -------------------------------------------------
-- Prueba de tabla alumnos
-- -------------------------------------------------

-- insert alumno valido
insert into alumnos (nombre, apellido, edad, idCurso) values
	('Lautaro','Martinez',34,1);										-- OK
    
select * from alumnos;

-- insert alumnos no validos

-- longitud mínima de nombre
insert into alumnos (nombre, apellido, edad, idCurso) values
	('La','Martinez',34,1);												-- ERROR
    
-- longitud máxima de nombre
insert into alumnos (nombre, apellido, edad, idCurso) values
	('Lautarito el mejor jugador de futbol','Martinez',34,1);			-- OK

-- longitud mínima de apellido
insert into alumnos (nombre, apellido, edad, idCurso) values
	('Lautaro','M',34,1);												-- ERROR
    
-- longitud máxima de apellido
insert into alumnos (nombre, apellido, edad, idCurso) values
	('Lautaro','Lautarito el mejor jugador de futbol',34,1);			-- OK

-- edad menor a 18
insert into alumnos (nombre, apellido, edad, idCurso) values
	('Lautaro','Martinez',17,1);										-- OK
    
-- edad mayor a 120
insert into alumnos (nombre, apellido, edad, idCurso) values
	('Lautaro','Martinez',121,1);										-- OK

-- Curso inexistente
insert into alumnos (nombre, apellido, edad, idCurso) values
	('Lautaro','Martinez',34,1588); 									-- OK


select * from alumnos;
select * from cursos;