package ar.org.centro8.curso.java.proyectofinal.sql;

import static org.junit.jupiter.api.Assertions.assertEquals;
import java.sql.Connection;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;
import ar.org.centro8.curso.java.proyectofinal.connector.Connector;


public class TestSQL {
    
    //TODO Realizar pruebas unitarias de la tabla alumnos

    private Connection conn=Connector.getConnection();

    @Test
    public void testCursoValido(){
        try{
            int x=conn.createStatement().executeUpdate("insert into cursos (titulo,profesor,dia,turno) values "+
                            "('Python','Mendez','LUNES','TARDE')");
            assertEquals(1, x);
        }catch(Exception e){
            assertEquals(false, true);
        }
    }

    @Test
    public void testCursoTituloLongMinima(){
        try{
            int x=conn.createStatement().executeUpdate("insert into cursos (titulo,profesor,dia,turno) values "+
                            "('Py','Mendez','LUNES','TARDE')");
            assertEquals(0, x);
        }catch(SQLException e){
            assertEquals(true, true);
        }catch(Exception e){
            assertEquals(false, true);
        }
    }

    @Test
    public void testCursoTituloLongMaxima(){
        try{
            int x=conn.createStatement().executeUpdate("insert into cursos (titulo,profesor,dia,turno) values "+
                            "('El mejor curso de python y del mundo','Mendez','LUNES','TARDE')");
            assertEquals(0, x);
        }catch(SQLException e){
            assertEquals(true, true);
        }catch(Exception e){
            assertEquals(false, true);
        }
    }

    @Test
    public void testCursoProfesorLongMinima(){
        try{
            int x=conn.createStatement().executeUpdate("insert into cursos (titulo,profesor,dia,turno) values "+
                            "('Python','Me','LUNES','TARDE')");
            assertEquals(0, x);
        }catch(SQLException e){
            assertEquals(true, true);
        }catch(Exception e){
            assertEquals(false, true);
        }
    }

    @Test
    public void testCursoProfesorLongMaxima(){
        try{
            int x=conn.createStatement().executeUpdate("insert into cursos (titulo,profesor,dia,turno) values "+
                            "('Python','El mejor profesor de python y del mundo','LUNES','TARDE')");
            assertEquals(0, x);
        }catch(SQLException e){
            assertEquals(true, true);
        }catch(Exception e){
            assertEquals(false, true);
        }
    }

    @Test
    public void testCursoDiaIncorrecto(){
        try{
            int x=conn.createStatement().executeUpdate("insert into cursos (titulo,profesor,dia,turno) values "+
                            "('Python','Mendez','OSVALDO','TARDE')");
            assertEquals(0, x);
        }catch(SQLException e){
            assertEquals(true, true);
        }catch(Exception e){
            assertEquals(false, true);
        }
    }

    @Test
    public void testCursoTurnoIncorrecto(){
        try{
            int x=conn.createStatement().executeUpdate("insert into cursos (titulo,profesor,dia,turno) values "+
                            "('Python','Mendez','LUNES','MADRUGADA')");
            assertEquals(0, x);
        }catch(SQLException e){
            assertEquals(true, true);
        }catch(Exception e){
            assertEquals(false, true);
        }
    }

}
