package ar.org.centro8.curso.java.proyectofinal.connector;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.sql.Connection;
import java.sql.ResultSet;
import java.time.Duration;
import java.time.LocalTime;

import org.junit.jupiter.api.Test;

public class ConnectorTest {
    private Connection conn=Connector.getConnection();

    /**
     * Se evalua que el connector no se nullo
     */
    @Test
    void testGetConnection1() {
        assertNotEquals(conn,null);
    }

    /**
     * Se evalua que el server de BD tenga conexión
     */
    @Test
    void testGetConnection2(){
        try{
            ResultSet rs=conn.createStatement().executeQuery("select version()");
            assertEquals(rs.next(), true);
        }catch(Exception e){
            assertEquals(false, true);
        }
    }

    /**
     * Se evalua que el server de BD de respuesta
     */
    @Test
    void testGetConnection3(){
        try{
            ResultSet rs=conn.createStatement().executeQuery("select version()");
            rs.next();
            assertEquals(rs.getString(1).length()>3, true);
        }catch(Exception e){
            assertEquals(false, true);
        }
    }

    /**
     * Se evalua que el tiempo de respuesta del server de BD sea menor a 2s
     */
    @Test
    void testGetConnection4(){

        LocalTime ldt1=LocalTime.now();
        try{
            ResultSet rs=conn.createStatement().executeQuery("select version()");
            if(rs.next()) rs.getString(1);
        }catch(Exception e){
            assertEquals(false, true);
        }
        LocalTime ldt2=LocalTime.now();
        Duration duration = Duration.between(ldt1, ldt2);
        if(duration.toMillis()<=200){
            assertEquals(true, true);
        }else{
            assertEquals(false, true);
        }

    }

}
