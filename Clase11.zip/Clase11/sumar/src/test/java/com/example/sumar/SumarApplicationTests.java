package com.example.sumar;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SumarApplicationTests {

	@Test
	void contextLoads() {
	}

	//Zona de testing
	//Escribimos casos de pruebas

	@Test
	void test1(){
		assertEquals(2, 2);			//OK GREEN
	}

	@Test
	void test2(){
		//assertEquals(2, 3);			//ERROR RED
	}

	@Test
	void test3(){
		assertEquals(4, (2+2));			//OK GREEN
	}

	@Test
	void test4(){
		//assertEquals(4, (2+1));			//OK GREEN
	}

	@Test
	void sumarTest1(){
		//suma de parámetros
		assertEquals(4, Sumar.sumar(2, 2));
	}

	@Test
	void sumarNumerosNegativos(){
		//suma de numeros negativos
		assertEquals(-4, Sumar.sumar(-2, -2));
	}

	@Test
	void sumarTest3(){
		assertEquals(10, Sumar.sumar(10, 0));
	}

	@Test
	void sumarTest4(){
		assertEquals(10, Sumar.sumar(10, -0));
	}

	@Test
	void sumarDesbordamiento1(){
		assertEquals(4000000000L, Sumar.sumar(2000000000, 2000000000));
	}
}
