package com.example.sumar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SumarApplicationTests {

	@Test
	void contextLoads() {
	}

	//Zona de testing
	//Escribimos casos de pruebas
	


}
