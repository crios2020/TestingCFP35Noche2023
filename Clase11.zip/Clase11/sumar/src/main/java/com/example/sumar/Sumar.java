package com.example.sumar;

public class Sumar {
    public static int sumar(int nro1, int nro2){
        return nro1+nro2;
    }
}
