package com.example.sumar;

public class Sumar {
    public static long sumar(int nro1, int nro2){
        return (long)nro1+nro2;
    }
}
