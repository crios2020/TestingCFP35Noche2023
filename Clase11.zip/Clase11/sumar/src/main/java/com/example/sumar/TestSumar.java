package com.example.sumar;

public class TestSumar {
    public static void main(String[] args) {
        
        //Objetos MOCKS - Objetos Simulados 
        System.out.println(Sumar.sumar(2, 2));          //4
        System.out.println(Sumar.sumar(0, -2));             //-2
        System.out.println(Sumar.sumar(-4, -2));                //-6

    }
}
