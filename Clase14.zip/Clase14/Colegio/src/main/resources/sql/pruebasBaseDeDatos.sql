use colegio;

-- https://www.tutorialesprogramacionya.com/mysqlya/

-- insert alumno valido
insert into alumnos (nombre, apellido, edad, idCurso) values
	('Lautaro','Martinez',34,1);
    
select * from alumnos;

-- insert alumnos no validos

-- longitud mínima de nombre
insert into alumnos (nombre, apellido, edad, idCurso) values
	('La','Martinez',34,1);
    
-- longitud máxima de nombre
insert into alumnos (nombre, apellido, edad, idCurso) values
	('Lautarito el mejor jugador de futbol','Martinez',34,1);

-- longitud mínima de apellido
insert into alumnos (nombre, apellido, edad, idCurso) values
	('Lautaro','M',34,1);
    
-- longitud máxima de apellido
insert into alumnos (nombre, apellido, edad, idCurso) values
	('Lautaro','Lautarito el mejor jugador de futbol',34,1);

-- edad menor a 18
insert into alumnos (nombre, apellido, edad, idCurso) values
	('Lautaro','Martinez',17,1);
    
-- edad mayor a 120
insert into alumnos (nombre, apellido, edad, idCurso) values
	('Lautaro','Martinez',121,1);

-- Curso inexistente
insert into alumnos (nombre, apellido, edad, idCurso) values
	('Lautaro','Martinez',34,1588);

select * from alumnos;
select * from cursos;